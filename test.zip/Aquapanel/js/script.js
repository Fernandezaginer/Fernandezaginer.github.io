//var mydata = JSON.parse(data);
//mydata.wakeup
var init_load = true;
refreshPage();
//setInterval(updateImage, 1000);



// --------------------------------------------------------------------------
//                          Auxiliar estilos css
// --------------------------------------------------------------------------

/*
window.onload = function () {
  var slider = document.getElementById("brillo");
  slider.addEventListener("input", function () {
    document.body.style.setProperty("--thumbNumber", "'" + this.value + "'");
  });
  // whenever this element receives input, change the value of --thumbNumber to this element's value
}
*/

function update_brillo(val) {
  document.getElementById('brillo_val').value = val;
}

function update_contraste(val) {
  document.getElementById('contraste_val').value = val;
}

function update_saturacion(val) {
  document.getElementById('saturacion_val').value = val;
}

function update_tono(val) {
  document.getElementById('tono_val').value = val;
}

function update_exposicion(val) {
  document.getElementById('exposicion_val').value = val;
}



// --------------------------------------------------------------------------
//                          Funciones auxiliares
// --------------------------------------------------------------------------

// Estilo del la lucecita del sensor disponible
function colorSensor(valorJSON) {
  let aux;
  if (valorJSON == "1" || valorJSON == "true") {
    aux = "sensorDisp";
  }
  else if (valorJSON == "0" || valorJSON == "false") {
    aux = "sensorNoDisp";
  }
  else {
    aux = "sensor";
  }
  return aux;
}

// Obtener el checked 
function checkedBT(valorJSON) {
  let aux;
  if (valorJSON == "1" || valorJSON == "true") {
    aux = true;
  }
  else if (valorJSON == "0" || valorJSON == "false") {
    aux = false;
  }
  else {
    aux = false;
  }
  return aux;
}

// Boolean to string
function bool_to_str(b) {
  if (b == true) {
    return "1";
  }
  else {
    return "0";
  }
}

// Funcion para abrir un .json
function loadJSON(callback, file) {
  console.log("Cargando JSON");
  var xobj = new XMLHttpRequest();
  xobj.overrideMimeType("application/json");
  xobj.open('GET', file, true);
  xobj.onreadystatechange = function () {
    if (xobj.readyState == 4 && xobj.status == "200") {
      callback(xobj.responseText);
    }
  };
  xobj.send(null);
}

// Realizar un post
function envioJson(cabecera, cuerpo) {
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: cuerpo
  };
  fetch(cabecera, options);
}











// --------------------------------------------------------------------------
//                   Callback para inicializar la pagina
// --------------------------------------------------------------------------


function refreshPage() {
  console.log("Inicializacion de la Webapp");

  // Inicializar ID
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    if(String(actual_JSON.update) == "true" || init_load == true){
      document.getElementById("ID").value = String(actual_JSON.ID);
      console.log("ID cargado");
      console.log(String(actual_JSON.ID));
      setTimeout(function() {send_id();}, 500);
    }

  }, 'js/json/id.json');


  // Iniciar parametros generales:
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    if(String(actual_JSON.update) == "true" || init_load == true){
      console.log(response);
      console.log(actual_JSON.jsonId);
      document.getElementById("wakeup").value = String(actual_JSON.wakeup);
      document.getElementById("sleep").value = String(actual_JSON.sleep);
      document.getElementById("freq_back").value = String(actual_JSON.freq_back);
      document.getElementById("modo_bt").checked = checkedBT(actual_JSON.modo_bt);
      console.log("Check BT:");
      console.log(String(checkedBT(actual_JSON.modo_bt)));
      let ip_str = String(actual_JSON.ip);
      let ip = ip_str.split(".");
      document.getElementById("ip1").value = String(ip[0]);
      document.getElementById("ip2").value = String(ip[1]);
      document.getElementById("ip3").value = String(ip[2]);
      document.getElementById("ip4").value = String(ip[3]);
      document.getElementById("telefono").value = String(actual_JSON.telefono);
      document.getElementById("latitud").value = String(actual_JSON.latitud);
      document.getElementById("longitud").value = String(actual_JSON.longitud);
      document.getElementById("interval").value = String(actual_JSON.interval);
      console.log("Parametros estacion cargados");
      setTimeout(function() {send_param();}, 500);
    }
  }, 'js/json/parameters.json');


  // Iniciar Fecha y hora
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    if(String(actual_JSON.update) == "true" || init_load == true){
      let date_time = String(actual_JSON.year) + '-' + String(actual_JSON.month) + '-' + String(actual_JSON.day) + 'T' + String(actual_JSON.hour) + ':' + String(actual_JSON.minute);
      document.getElementById("fecha").value = date_time;
      console.log("Fecha y hora cargados");
      setTimeout(function() {send_hora();}, 500);
    }
  }, 'js/json/time.json');


  // Inicializar sensores disponibles
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    document.getElementById("Acelerometro").className = colorSensor(String(actual_JSON.Acelerometro));
    document.getElementById("HIDS").className = colorSensor(String(actual_JSON.HIDS));
    document.getElementById("PADS").className = colorSensor(String(actual_JSON.PADS));
    document.getElementById("OPT").className = colorSensor(String(actual_JSON.OPT));
    document.getElementById("URM13").className = colorSensor(String(actual_JSON.URM13));
    document.getElementById("MLX90632").className = colorSensor(String(actual_JSON.MLX90632));
    document.getElementById("SD").className = colorSensor(String(actual_JSON.SD));
    console.log("Sensores disponibles cargados");
  }, 'js/json/dispSens.json');


  // Inicializar parameros camara
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
      if(String(actual_JSON.update) == "true" || init_load == true){
      document.getElementById("camModelo").value = String(actual_JSON.camModelo);
      document.getElementById("brillo").value = String(actual_JSON.brillo);
      document.getElementById("contraste").value = String(actual_JSON.contraste);
      document.getElementById("saturacion").value = String(actual_JSON.saturacion);
      document.getElementById("ganancia").value = String(actual_JSON.ganancia);
      document.getElementById("tono").value = String(actual_JSON.tono);
      document.getElementById("exposicion").value = String(actual_JSON.exposicion);
      document.getElementById("tiempoExposicion").value = String(actual_JSON.tiempoExposicion);
      update_brillo(String(actual_JSON.brillo));
      update_contraste(String(actual_JSON.contraste));
      update_saturacion(String(actual_JSON.saturacion));
      update_tono(String(actual_JSON.tono));
      update_exposicion(String(actual_JSON.exposicion));
      console.log("Parametros camara cargados");
      setTimeout(function() {send_camara();}, 500);
    }
  }, 'js/json/camera.json');


  // Iniclializar lecuras de los sensores
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    document.getElementById("InclinacionX").value = String(actual_JSON.InclinacionX);
    document.getElementById("InclinacionY").value = String(actual_JSON.InclinacionY);
    document.getElementById("Humedad").value = String(actual_JSON.Humedad);
    document.getElementById("Presion").value = String(actual_JSON.Presion);
    document.getElementById("Iluminacion").value = String(actual_JSON.Iluminacion);
    document.getElementById("Distancia").value = String(actual_JSON.Distancia);
    document.getElementById("TempHids").value = String(actual_JSON.TempHids);
    document.getElementById("TempPads").value = String(actual_JSON.TempPads);
    document.getElementById("TempAgua").value = String(actual_JSON.TempAgua);
    document.getElementById("TempAmb").value = String(actual_JSON.TempAmb);
    console.log("Lecturas sensores cargadas");
  }, 'js/json/dataSens.json');


  // Inicializar datos modem
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    document.getElementById("RRSI").value = String(actual_JSON.RRSI);
    document.getElementById("Operadora").value = String(actual_JSON.Operadora);
    document.getElementById("Red").value = String(actual_JSON.Red);
    document.getElementById("Modo").value = String(actual_JSON.Modo);
    document.getElementById("PLMN1").value = String(actual_JSON.PLMN1);
    document.getElementById("PLMN2").value = String(actual_JSON.PLMN2);
    document.getElementById("TAC").value = String(actual_JSON.TAC);
    document.getElementById("SCell_ID").value = String(actual_JSON.SCell_ID);
    document.getElementById("PCell_ID").value = String(actual_JSON.PCell_ID);
    document.getElementById("RSRQ").value = String(actual_JSON.RSRQ);
    document.getElementById("RSRP").value = String(actual_JSON.RSRP);
    document.getElementById("RSSNR").value = String(actual_JSON.RSSNR);
    console.log("Info Modem cargada");
  }, 'js/json/modem.json');


  init_load = false;

}












// --------------------------------------------------------------------------
//              Callbacks de boton de envio de datos presionado
// --------------------------------------------------------------------------

// ID
const update_id = (ev) => {
  ev.preventDefault();
  send_id();
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_id").addEventListener('click', update_id);
});

function send_id(){
  let data = {
    "jsonId": "idJson",
    "update" : "false",
    "ID": document.getElementById('ID').value
  }
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  };
  console.log(data);
  console.log(JSON.stringify(data));
  fetch('/update_id', options);
}



// Parametros fecha y hora
const update_hora = (ev) => {
  ev.preventDefault();
  send_hora();
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_hora").addEventListener('click', update_hora);
});

function send_hora(){
  let date_time = document.getElementById("fecha").value;
  let year = date_time[0] + date_time[1] + date_time[2] + date_time[3];
  let month = date_time[5] + date_time[6];
  let day = date_time[8] + date_time[9];
  let hour = date_time[11] + date_time[12];
  let minute = date_time[14] + date_time[15];

  let data = {
    "jsonId": "fyhJson",
    "update" : "false",
    "year": year,
    "month": month,
    "day": day,
    "hour": hour,
    "minute": minute
  }

  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  };
  console.log(data);
  console.log(JSON.stringify(data));
  fetch('/update_hora', options);
}



// Parametros
const update_param = (ev) => {
  ev.preventDefault();
  send_param();
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_param").addEventListener('click', update_param);
});

function send_param(){
  let ip = document.getElementById('ip1').value + "." + document.getElementById('ip2').value + "." + document.getElementById('ip3').value + "." + document.getElementById('ip4').value;

  let data = {
    "jsonId": "paramJson",
    "update" : "false",
    "wakeup": document.getElementById('wakeup').value,
    "sleep": document.getElementById('sleep').value,
    "freq_back": document.getElementById('freq_back').value,
    "mode": document.getElementById('mode').value,
    "modo_bt": bool_to_str(document.getElementById('modo_bt').checked),
    "ip": ip,
    "telefono": document.getElementById('telefono').value,
    "latitud": document.getElementById('latitud').value,
    "longitud": document.getElementById('longitud').value,
    "interval": document.getElementById('interval').value
  }
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  };
  console.log(data);
  console.log(JSON.stringify(data));
  fetch('/update_param', options);
}



// Camara
const update_camara = (ev) => {
  ev.preventDefault();
  send_camara();
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_camara").addEventListener('click', update_camara);
});

function send_camara(){
  
  let data = {
    "jsonId": "camJson",
    "update" : "false",
    "camModelo": document.getElementById('camModelo').value,
    "brillo": document.getElementById('brillo').value,
    "contraste": document.getElementById('contraste').value,
    "saturacion": document.getElementById('saturacion').value,
    "ganancia": document.getElementById('ganancia').value,
    "tono": document.getElementById('tono').value,
    "exposicion": document.getElementById('exposicion').value,
    "tiempoExposicion": document.getElementById('tiempoExposicion').value
  }
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  };
  console.log(data);
  console.log(JSON.stringify(data));
  fetch('/update_camara', options);
}










// --------------------------------------------------------------------------
//                   Callback de boton de aviso presionado
// --------------------------------------------------------------------------


const update_Foco_ON = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.foco = "1";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Foco_ON").addEventListener('click', update_Foco_ON);
});

const update_Foco_OFF = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.foco = "0";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Foco_OFF").addEventListener('click', update_Foco_OFF);
});


const update_Noche_ON = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.noche = "1";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Noche_ON").addEventListener('click', update_Noche_ON);
});


const update_Noche_OFF = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.noche = "0";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Noche_OFF").addEventListener('click', update_Noche_OFF);
});


const update_Env_continuo_ON = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.envio = "1";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Env_continuo_ON").addEventListener('click', update_Env_continuo_ON);
});


const update_Env_continuo_OFF = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.envio = "0";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Env_continuo_OFF").addEventListener('click', update_Env_continuo_OFF);
});


const update_Habilitar_SD = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.sd = "1";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Habilitar_SD").addEventListener('click', update_Habilitar_SD);
});


const update_Deshabilitar_SD = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.sd = "0";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Deshabilitar_SD").addEventListener('click', update_Deshabilitar_SD);
});


const update_Sleep_ON = (ev) => {
  ev.preventDefault();

  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.sleep = "1";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');

}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Sleep_ON").addEventListener('click', update_Sleep_ON);
});


const update_Sleep_OFF = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    actual_JSON.sleep = "0";
    envioJson('/update_mensajes', JSON.stringify(actual_JSON));
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Sleep_OFF").addEventListener('click', update_Sleep_OFF);
});




const update_Reset_Estacion = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    if (actual_JSON.ack_estacion != "ok") {
      alert("Envio no realizado, espere...");
    }
    else {
      actual_JSON.mensaje = "resetEstacion";
      actual_JSON.ack_estacion = "false";
      envioJson('/update_mensajes', JSON.stringify(actual_JSON));
    }
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("update_Reset_Estacion").addEventListener('click', update_Reset_Estacion);
});


const ResetModem = (ev) => {
  ev.preventDefault();
  loadJSON(function (response) {
    var actual_JSON = JSON.parse(response);
    if (actual_JSON.ack_estacion != "ok") {
      alert("Envio no realizado, espere...");
    }
    else {
      actual_JSON.mensaje = "resetModem";
      actual_JSON.ack_estacion = "false";
      envioJson('/update_mensajes', JSON.stringify(actual_JSON));
    }
  }, 'js/json/mensajes.json');
}
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("ResetModem").addEventListener('click', ResetModem);
});











// --------------------------------------------------------------------------
//                     Callbacks de actualizacion
// --------------------------------------------------------------------------

// Actualizar la imagen
window.onload = function () {
  var image = document.getElementById("feed");
  
  init_load = true;

  function updateImage() {
    var image = document.getElementById("feed");
    image.src = image.src.split("?")[0] + "?" + new Date().getTime();
    refreshPage();
    //document.getElementById("fecha").value = "2021-09-15T15:38";
    //console.log(document.getElementById("fecha").value);
  }

  setInterval(updateImage, 5000);   // Intervalo de actualizacion de imagen y datos en ms
}


// Actualizar el resto de parametros
/*
window.onload = function () {

  init_load = true;

  function updateParam() {
    refreshPage();
  }
  setInterval(updateParam, 5000);   // Intervalo de actualizacion
}
*/


