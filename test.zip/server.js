console.log("Server is starting")

var port = 80;
var express = require('express');
var app = express();
var server = app.listen(port, listening);
var fs = require('fs');

try {
  var ip = require("ip");
  console.log("http://" + ip.address() + ":" + port);
} catch (error) {
  console.log("IP not available:");
  console.error(error);
}


function listening()
{
  console.log("listening. . .");
}

app.use(express.static('Aquapanel'));
app.use(express.json());


// --------------------------------------------------------------------------
//                     Callbacks para guardar json
// --------------------------------------------------------------------------


app.post('/update_id', function(request, response)
{
  console.log(request.body);
  fs.writeFile('Aquapanel/js/json/id.json',JSON.stringify(request.body, null, 2), finished);

  function finished(err) {
    if (err) {
      console.error(err, 'Uncaught Exception thrown');
    }
  }
  response.end();
});


app.post('/update_hora', function(request, response)
{
  console.log(request.body);
  fs.writeFile('Aquapanel/js/json/time.json',JSON.stringify(request.body, null, 2), finished);

  function finished(err) {
    if (err) {
      console.error(err, 'Uncaught Exception thrown');
    }
  }
  response.end();
});


app.post('/update_param', function(request, response)
{
  console.log(request.body);
  fs.writeFile('Aquapanel/js/json/parameters.json',JSON.stringify(request.body, null, 2), finished);

  function finished(err) {
    if (err) {
      console.error(err, 'Uncaught Exception thrown');
    }
  }
  response.end();
});



app.post('/update_camara', function(request, response)
{
  console.log(request.body);
  fs.writeFile('Aquapanel/js/json/camera.json',JSON.stringify(request.body, null, 2), finished);

  function finished(err) {
    if (err) {
      console.error(err, 'Uncaught Exception thrown');
    }
  }
  response.end();
});


app.post('/update_mensajes', function(request, response)
{
  console.log(request.body);
  fs.writeFile('Aquapanel/js/json/mensajes.json',JSON.stringify(request.body, null, 2), finished);

  function finished(err) {
    if (err) {
      console.error(err, 'Uncaught Exception thrown');
    }
  }
  response.end();
});


